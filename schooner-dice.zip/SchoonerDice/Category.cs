public enum Category
{
    Ones = 1,
    Twos = 2,
    Threes = 3,
    Fours = 4,
    Fives = 5,
    Sixes = 6,
    Sevens = 7,
    Eights = 8,
    ThreeOfaKind = 9,
    FourOfaKind = 10,
    FullHouse = 11,
    SmallStraight = 12,
    AllDifferent = 13,
    LargeStraight = 14,
    Schooner = 15,
    Chance = 16
}
